Here is an example of running my solution to the HW 7 programming problem.

*stewart@mac sol $ crawler file1.txt file10.txt <keywords.txt
FILES OPENED
file1.txt
file10.txt
file2.txt
file3.txt
file6.txt
file7.txt
file8.txt
file9.txt

FILE LINKS FOUND THAT COULD NOT BE OPENED
file4.txt
file5.txt

lincoln appears in files
file1.txt
file2.txt
file10.txt
file6.txt
file7.txt
file8.txt

washington appears in files
file1.txt
file7.txt
file8.txt

jefferson appears in files
file7.txt

adams appears in files
-none-
