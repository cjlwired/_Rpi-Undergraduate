// Carlos Lazo
// 10-11-05
// DSA Homework #3

#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "MaxPriorityQueue.h"

using namespace std;

// Default Constructor

MaxPriorityQueue::MaxPriorityQueue()
{
	heap_size = 0;
}

//Destructor

MaxPriorityQueue::~MaxPriorityQueue()
{}

/* *******************
   * Heap Operations *
   ******************* */

// Build the heap first, then sort the heap using the heap sort algorithm.

void MaxPriorityQueue::heapsort()
{
	build_heap();

	for (int i = heap_size; i > 1; i--)
	{
		Job temp = heap[0];
		heap[0] = heap[i-1];
		heap[i-1] = temp;

		heap_size--;

		heapify(1);
	}
}

void MaxPriorityQueue::build_heap()
{
	// Build the heap using the heapify function.

	for (int i = heap_size/2; i > 0; i--)
	{
		heapify(i);
	}

}

// Heapify function used with heapsort.

void MaxPriorityQueue::heapify(int index)
{

	// Recursive function to determine which of the elements, the current node or its two children 
	// are the largest.

	int l_index = index * 2;
	int r_index = (index * 2) + 1;

	int largest;

	// Make sure to account for the vector indexing starting at 0 and not 1.

	if ((l_index <= heap_size) && (heap[l_index - 1].Job_Priority < heap[index - 1].Job_Priority))
		largest = l_index;
	else
		largest = index;

	if ((r_index <= heap_size) && (heap[r_index - 1].Job_Priority < heap[largest - 1].Job_Priority))
		largest = r_index;

	if (largest != index)
	{
		Job temp = heap[index - 1];
		heap[index - 1] = heap[largest - 1];
		heap[largest - 1] = temp;

		heapify(largest);
	}
		
}

/* *******************************
   * MaxPriorityQueue Operations *
   *******************************  */

// Insert the new Job into the queue and then sort it.

void MaxPriorityQueue::insert(Job job)
{
	heap.push_back(job);

	heap_size = heap.size();

	heapsort();
}

// Return the element with the highest priority.

Job MaxPriorityQueue::highest_priority()
{
	return heap[0];
}

// Remove Job with the highest priority from the queue.

void MaxPriorityQueue::extract_max()
{
	bool flag = true;

	if (heap.size() > 1)
	{
		for (int i = 0; i < heap.size() - 1; i++)
		{
			Job temp = heap[i];
			heap[i] = heap[i+1];
			heap[i+1] = temp;
		}
	}

	if (heap.size() > 1)
	{
		flag = false;
		heap.pop_back();	// After shifting all elements one to the left, pop the back of the vector.
	}

	if ((heap.size() == 1) && flag)
	{
		heap.resize(0);
	}

}

// Print out the size of the Priority Queue

int MaxPriorityQueue::size()
{
	return heap.size();
}

// Print out Jobs in the Priority Queue

void MaxPriorityQueue::print()
{	
	cout << setw(15) << "JOB ID" << setw(15) << "Job Priority" << setw(15) << "Job Time" << endl << endl;

	for (int i = 0; i < heap.size(); i++)
		cout << setw(15) << heap[i].Job_ID << setw(15) << heap[i].Job_Priority << setw(15) << heap[i].Job_Time << endl;

	cout << endl;
}