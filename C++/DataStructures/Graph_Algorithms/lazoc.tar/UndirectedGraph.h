// Carlos Lazo
// 10-31-05
// DSA Homework #6

/* header file for UndirectedGraph class */

#include <iostream>
#include <vector>

#include "Vertex.h"

class UndirectedGraph
{
public:
	/* Constructor/Destructor */
	UndirectedGraph() : _size(0) {}
	UndirectedGraph(const UndirectedGraph& dg);
	~UndirectedGraph() {}

	UndirectedGraph& operator=(const UndirectedGraph& dg);

	/* Vertex functions */
	int addVertex();
	bool containsVertex(int index);

	/* Edge functions */
	void addEdge(int src, int dest, int weight);
	void removeEdge(int src, int dest);
	bool containsEdge(int src, int dest);
	int getEdgeWeight(int src, int dest);
	int totalWeight();

	/* general functions */
	void printVertex(int index);
	void printAll();
	int size();

	std::vector<vertex> verts;
	int _size;
};
