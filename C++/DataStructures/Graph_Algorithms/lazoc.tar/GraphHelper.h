// Carlos Lazo
// 10-31-05
// DSA Homework #6

#include <iostream>
#include <string>
#include <vector>

#include "DirectedGraph.h"
#include "MinPriorityQueue.h"
#include "UndirectedGraph.h"

class GraphHelper
{
	public:
	
		GraphHelper() {}	// Default constructor

		DirectedGraph dijkstraSP(DirectedGraph g, int start);	// Implementation of Dijkstra's Shortest Path algorithm.
		UndirectedGraph primMST(UndirectedGraph g, int start);

};


