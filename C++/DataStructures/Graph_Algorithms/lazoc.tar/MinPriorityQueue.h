// Carlos Lazo
// 10-31-05
// DSA Homework #6

#include <iostream>
#include <vector>
#include <string>
#include "Vertex.h"

using namespace std;
class MinPriorityQueue{
public:
	vector<vertex> priority_queue;
	void heapify(int index);
	/*constructor*/
	MinPriorityQueue(){}
	/*destructor*/	~MinPriorityQueue(){priority_queue.clear();} 

	void insert(vertex v);
	vertex highest_priority(){return priority_queue[0];} 
	void extract_min();
	int size(){return priority_queue.size();} 

};