// Carlos Lazo
// 10-31-05
// DSA Homework #6

#include <climits>
#include <iostream>
#include <vector>

#include "GraphHelper.h"

#define INFINITY INT_MAX;	// Define infinity to be the maximum possible value.

using namespace std;

DirectedGraph GraphHelper::dijkstraSP(DirectedGraph g, int start)
{
	// Set minimum distance for all vertices to 0.
	// Set predecessors for all vertices to 0.

	for (int i = 0; i < g.size(); i++)
	{
		g.verts[i].dist = INFINITY;
		g.verts[i].predecessor = NULL;
	}

	// Set the distance from the source = 0

	g.verts[start].dist = 0;

	MinPriorityQueue T;	// Store vertices once they are extracted.
	MinPriorityQueue Q;	// Store initial vertices of the graph.

	// Insert all vertices of g into Q.

	for (int i = 0; i < g.size(); i++)
		Q.insert(g.verts[i]);

	while (Q.size() != 0)
	{
		vertex u = Q.highest_priority();

		Q.extract_min();
	
		T.insert(u);

		// Relax vertices in graph, then update PriorityQueue.

		for (int i = 0; i < u.edges.size(); i++)
		{
			int v = u.edges[i].dest;

			if (g.verts[v].dist > (u.dist + g.getEdgeWeight(u.edges[0].src, v)))
			{
				g.verts[v].dist = u.dist + g.getEdgeWeight(u.edges[0].src, v);

				for (int j = 0; j < Q.size(); j++)
				{
					if (Q.priority_queue[j].edges.size() != 0)
						if (Q.priority_queue[j].edges[0].src == v)
							Q.priority_queue[j].dist = u.dist + g.getEdgeWeight(u.edges[0].src, v);

					else
						if (g.verts[v].edges.size() == 0 && Q.priority_queue[j].edges.size() == 0)
							Q.priority_queue[j].dist = u.dist + g.getEdgeWeight(u.edges[0].src, v);
				}	
			}
		}
	}

	// End relaxation period.

	DirectedGraph dirgph;

	for (int i = 0; i < T.size(); i++)
		dirgph.addVertex();

	while (T.size() != 0)
	{
		vertex u = T.highest_priority();
		T.extract_min();

		if (u.edges.size() > 0)
		{
			for (int i = 0; i < u.edges.size(); i++)
			{

				int v = u.edges[i].dest;

				if (g.verts[v].dist == (u.dist + g.getEdgeWeight(u.edges[0].src, v)))
					dirgph.addEdge(u.edges[i].src, v, u.edges[i].weight);
			}
		}
	}

	return dirgph;
}

UndirectedGraph GraphHelper::primMST(UndirectedGraph g, int start)
{

	MinPriorityQueue Q;	// Store initial vertices of the graph.

	// Insert all vertices of g into Q.

	for (int i = 0; i < g.size(); i++)
		Q.insert(g.verts[i]);

	// Set keys for all vertices to 0.
	// Set predecessors for all vertices to 0.

	for (int i = 0; i < g.size(); i++)
	{
		g.verts[i].key = INFINITY;
		g.verts[i].predecessor = NULL;
	}

	// Set the key from the source = 0

	g.verts[start].key = 0;

	while (Q.size() != 0)
	{
		vertex u = Q.highest_priority();
		Q.extract_min();

		// Perform key comparisons, similar to relax.

		for (int i = 0; i < u.edges.size(); i++)
		{
			int v = u.edges[i].dest;

			if (g.getEdgeWeight(u.edges[0].src, v) < g.verts[v].key)
				g.verts[v].key = g.getEdgeWeight(u.edges[0].src, v);
		}
	}

	cout << endl;

	UndirectedGraph undirgph;

	for (int i = 0; i < g.size(); i++)
		undirgph.addVertex();

	for (int x = 0; x < g.size(); x++)
	{

		vertex u = g.verts[x];

		if (u.edges.size() > 0)
		{
			for (int i = 0; i < u.edges.size(); i++)
			{

				int v = u.edges[i].dest;

				if  (u.key < g.verts[v].key)
					undirgph.addEdge(u.edges[i].src, v, u.edges[i].weight);
			}
		}
	}

	return undirgph;
}