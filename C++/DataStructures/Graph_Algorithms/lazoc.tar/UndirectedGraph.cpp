// Carlos Lazo
// 10-31-05
// DSA Homework #6

/* implementation file for UnUndirectedGraph class */

#include "UndirectedGraph.h"

/* copy constructor */
UndirectedGraph::UndirectedGraph(const UndirectedGraph& dg)
{
	int i,j,len;

	const vertex* pv;

	_size = dg._size;
	
	/* loop through and copy all vertex information */
	for (i=0; i<_size; ++i)
	{
		verts.push_back(vertex());

		pv = &(dg.verts[i]);
		len = pv->edges.size();

		/* loop through edges */
		for (j=0; j<len; ++j)
			verts[i].edges.push_back(edge(i, pv->edges[j].dest,
					pv->edges[j].weight));
	}
}

/* assignment operator */
UndirectedGraph& UndirectedGraph::operator=(const UndirectedGraph& dg)
{
	int i,j,len;

	const vertex* pv;

	_size = dg._size;

	verts.clear();
	
	/* loop through and copy all vertex information */
	for (i=0; i<_size; ++i)
	{
		verts.push_back(vertex());

		pv = &(dg.verts[i]);
		len = pv->edges.size();

		verts[i].edges.clear();

		/* loop through edges */
		for (j=0; j<len; ++j)
			verts[i].edges.push_back(edge(i, pv->edges[j].dest,
					pv->edges[j].weight));
	}

	return (*this);
}

/* add vertex specified by index */
int UndirectedGraph::addVertex()
{
	int old_size = _size;
	
	verts.push_back(vertex());
	_size = verts.size();
	return old_size;
}

/* see if vertex specified by index exists */
bool UndirectedGraph::containsVertex(int index)
{
	if (index < _size && index >= 0)
		return true;

	return false;
}

/* add edge specified by source and dest, and from the dest to source */
void UndirectedGraph::addEdge(int src, int dest, int weight)
{
	int len1, len2;
	vertex* pv1;
	vertex* pv2;
	
	/* simple check of input validity */
	if (src >= _size || dest >= _size || src < 0 || dest < 0)
		return;

	pv1 = &verts[src];
	pv2 = &verts[dest];

	len1 = pv1->edges.size();
	len2 = pv2->edges.size();

	bool flag1 = false;
	bool flag2 = false;
	
	
	/* check through all edges */
	for (int i=0; i < len1; ++i)
	{
		/* if it already exists, just change the weight */
		if (pv1->edges[i].dest == dest)
		{
			pv1->edges[i].weight = weight;
			flag1 = true;
		}
	}

	for (int j=0; j < len2; ++j)
	{
		/* if it already exists, just change the weight */
		if (pv2->edges[j].dest == src)
		{
			pv1->edges[i].weight = weight;
			flag2 = true;
		}
	}

	if (flag1 && flag2)
		return;

	if (!flag1)
		pv1->edges.push_back(edge(src,dest, weight));

	if (!flag2)
		pv2->edges.push_back(edge(dest,src, weight));

}

/* remove edge specified by source and dest, and by dest and source */
void UndirectedGraph::removeEdge(int src, int dest)
{
	int len1, len2;
	vertex* pv1, *pv2;
	edge* pe1, *pe2, *plast1, *plast2;

	/* simple check of input validity */
	if (src >= _size || dest >= _size || src < 0 || dest < 0)
		return;

	pv1 = &verts[src];
	pv2 = &verts[dest];
	len1 = pv1->edges.size();
	len2 = pv1->edges.size();
	

	/* scan through to find the edge */
	for (int i=0; i<len1; ++i)
	{
		/* found the one to remove, swap it with last and decrement */
		if (pv1->edges[i].dest == dest)
		{
			pe1 = &(pv1->edges[i]);
			plast1 = &(pv1->edges.back());

			pe1->dest = plast1->dest;
			pe1->weight = plast1->weight;
			
			pv1->edges.pop_back();
		}
	}
}

/* see if edge exists specified by source and dest */
bool UndirectedGraph::containsEdge(int src, int dest)
{
	int i, len;
	vertex* pv;

	/* simple check of input validity */
	if (src >= _size || dest >= _size || src < 0 || dest < 0)
		return false;

	pv = &verts[src];
	len = pv->edges.size();
	

	/* scan through to find the edge */
	for (i=0; i<len; ++i)
		/* found edge, return */
		if (pv->edges[i].dest == dest)
			return true;

	return false;
}

/* return edge weight specified by source and dest */
int UndirectedGraph::getEdgeWeight(int src, int dest)
{
	int i, len;
	vertex* pv;

	/* simple check of input validity */
	if (src >= _size || dest >= _size || src < 0 || dest < 0)
		return 0;

	pv = &verts[src];
	len = pv->edges.size();
	

	/* scan through to find the edge */
	for (i=0; i<len; ++i)
		/* found edge, return answer */
		if (pv->edges[i].dest == dest)
			return pv->edges[i].weight;

	return 0;
}

/* print out the weight of the graph */

int UndirectedGraph::totalWeight()
{

	int sum = 0;

	for (int i = 0; i < verts.size(); i++)
		for (int j = 0; j < verts[i].edges.size(); j++)
			sum += verts[i].edges[j].weight;

	return (sum / 2);
}


/* print a specific vertex, designated by the index */
void UndirectedGraph::printVertex(int index)
{
	int i, len;
	vertex* pv;
	edge* pe;

	std::cout << "Vertex " << index << ":";

	pv = &verts[index];
	len = pv->edges.size();
	

	/* scan through and print edges */
	for (i=0; i<len; ++i)
	{
		pe = &(pv->edges[i]);
		std::cout << " " << pe->dest << " (" << pe->weight << "),";
	}
	
	std::cout << std::endl;
}

/* print the vertices in order */
void UndirectedGraph::printAll()
{
	int i;

	for (i=0; i<_size; ++i)
		printVertex(i);
}

/* return size */
int UndirectedGraph::size()
{
	return _size;
}
