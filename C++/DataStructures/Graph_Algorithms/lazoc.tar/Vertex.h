#include <iostream>
#include <vector>

using namespace std;

#ifndef Vertex_h_
#define Vertex_h_

class edge
{
	public:
		edge() : src(0), dest(0), weight(0) {}
		edge(int s, int d, int w) : src(s), dest(d), weight(w) {}
		int src;
		int dest;
		int weight;
};

class vertex
{
	public:
		std::vector<edge> edges;
		int dist;					// Minimum distance to that vertex.
		vertex* predecessor;		// Pointer to the predecessor of the vertex.
		int key;					// Key to be used to compare nodes with Prim.
};

#endif