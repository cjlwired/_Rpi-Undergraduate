// Carlos Lazo
// 10-31-05
// DSA Homework #6

#include <iostream>
#include <vector>
#include "MinPriorityQueue.h"

using namespace std;
void MinPriorityQueue::insert(vertex v)
{
	/*Everytime you insert a job, put the job at the end of the list and then heapify*/
	priority_queue.push_back(v);
	for(int i = priority_queue.size()/2; i>=0; i--) 
		heapify(i);
}
void MinPriorityQueue::extract_min()
{
	/*Everytime you extract the Min, delete the root and use the last element to replace the root. Then heapify*/
	priority_queue[0] = priority_queue[int(priority_queue.size()-1)]; 
	priority_queue.pop_back();
	heapify(0);
}// Change implementation to use vertex distances.
void MinPriorityQueue::heapify(int index)
{
	/*implementation of pseudocode from lectures*/
	int left = 2*index+1;
	int right = 2*index+2;
	int largest;
	if(left < priority_queue.size() && priority_queue[left].dist < priority_queue[index].dist)
		largest = left;
	else
		largest = index;
	if(right < priority_queue.size() && priority_queue[right].dist < priority_queue[largest].dist)
		largest = right;
	if(largest != index)
	{
		vertex temp = priority_queue[index];
		priority_queue[index] = priority_queue[largest];
		priority_queue[largest] = temp;
		heapify(largest);
	}
}
