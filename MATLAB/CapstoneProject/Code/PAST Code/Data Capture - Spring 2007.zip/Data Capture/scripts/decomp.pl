#!/usr/bin/perl
use strict;
use warnings;
use File::Copy;

while(1==1){	#forever...
	readDir();
	print "Capture directory process complete.  Sleeping...\n";
	sleep(3);#sleep for 3 seconds.
}

#read all files in directory and decompress
sub readDir{
    print "Opening /mnt/rd/capture...\n";
    opendir my $dir, '/mnt/rd/capture' or die ("Cannot open /mnt/rd/capture $!");
    chdir '/mnt/rd/capture' or die ("Cannot change directory: $!");
    my $file;
    #my @temp;
    while (($file = readdir $dir)){
	if (defined $file && !($file eq '.' || $file eq '..')){
	    chomp($file);
            $file=~m/(.*)\.jpg/i;
	    print "\tDecompressing $file to $1 .bmp\n";

	    my @argsb= ("/mnt/scripts/djpeg", "-grayscale","-bmp", "-outfile", "/mnt/rd/bitmap/$1.bmp", "/mnt/rd/capture/$file");
	    system(@argsb);

	    move("/mnt/rd/capture/$file", "/mnt/images/archive/$file");
	}
    }
    closedir $dir;
}
