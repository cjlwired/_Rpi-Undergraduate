#!/usr/bin/perl
use strict;
use warnings;
use IO::Socket;

my $sock = new IO::Socket::INET (
        PeerAddr => 'localhost',
        PeerPort => '31337',
        Proto => 'tcp',
				 );
die  "Could not create socket: $!\n" unless $sock;

my $program="/mnt/scripts/bmp_diff";   
#this is the c program written by data process team.  
#takes 3 arguements, file to process, where to save processed, and base image

my ($base, $thisfile);
	#ask for new file
print $sock "done:\n"; 

#loop forever
my $line;
while(1 == 1) {
	#wait for response
	$line = <$sock>;
	print "$line";

	#accepts the following commands from server::
	 #filename:filename.bmp
	 #basename:baseimage.bmp
	if ($line=~m/^basename:(.*)/i) {
		$base="/mnt/rd/base/$1";
		print "New Base Set: $1\n";
	} elsif ($line=~m/^filename:(.+)/i) {
	        # if no base image, ask for baseimage
		if (!$base) { 
		    warn "No base image set!\n";
		    print $sock "basename:\n";
		    next;
		}
		$thisfile = $1;
		my $bitmap = "/mnt/rd/bitmap/$1";
		my $output = "/mnt/images/processed/$1";
		print "calling system ($program, $bitmap, $base, $output)";	
		system ($program, $bitmap, $base, $output);
# or warn "Error calling $program with '$bitmap', '$base', '$output' \n";
		#ask for new file
		print $sock "done:$thisfile\n"; 
	} else{
	        print $sock "done:\n";
	}
}
close($sock);
