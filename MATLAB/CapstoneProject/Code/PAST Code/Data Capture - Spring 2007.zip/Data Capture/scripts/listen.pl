#!/usr/bin/perl

use strict;
use warnings;
use IO::Socket; 

my $sock = new IO::Socket::INET ( 
	LocalHost => 'localhost', 
	LocalPort => '31337', 
	Proto => 'tcp', 
	Listen => 1, 
	Reuse => 1, 
); 

die "Could not create socket: $!\n" unless $sock;

my (@images, @processing);      # @images - queue of images in directory waiting to be processed
                                # @processing - queue of images currently being processed

my $baseimg = getBaseImage();
readDir();

my $new_sock = $sock->accept(); 
my $incoming = <$new_sock>;
my $nextfile;

print $new_sock "basename:$baseimg\n";

while(!defined $incoming || $incoming!~/quit/i) {
    #print "LIST:\n";
    #displayArray(@images);
    #print "\n\n";

    if (defined $incoming){
	print $incoming;
	if ($incoming =~ /^list/i){
	    displayArray(@images);
	} elsif ($incoming =~ /^process/i){
	    displayArray(@processing);
	} elsif ($incoming =~ /^done:(.*\.bmp)?/i){
	    $nextfile = getNextImage($1);
	    if (defined $nextfile){
		print $new_sock "filename:$nextfile\n";
	    } else{
		print $new_sock "filename:\n";
	    }
	} elsif ($incoming =~ /^basename/i){
	    $baseimg = getBaseImage();
	    print $new_sock "basename:$baseimg\n";
	}
    }
    $incoming = <$new_sock>;
}

close($new_sock);




# reads images in directory, saves to @images
sub readDir{
    opendir my $dir, '/mnt/rd/bitmap' or die ("Cannot open /mnt/rd/bitmap $!");
    chdir '/mnt/rd/bitmap' or die ("Cannot change directory: $!");

    my $file;
    my $count = 0;
    # read files from dir
    while (($file = readdir $dir)){
	chomp($file);

	# queue bitmap files that haven't already been added
	if (-f $file && $file =~ /.bmp$/i && !find($file, @images) && !find($file, @processing)){
	    push @images, $file;
	    $count++;
	}
    }

    @images = sort @images;

    # if no images are left, sleep a bit so it's not constantly checking (optional)
    if ($count == 0 && @images == 0){
	sleep(1);
    }

    closedir $dir;
}

# returns an image from /mnt/rd/base
sub getBaseImage{
    opendir my $dir, '/mnt/rd/base' or die ("Cannot open /mnt/rd/base $!");
    chdir '/mnt/rd/base' or die ("Cannot change directory $!");
    my $file;
    while (($file = readdir $dir)){
	if (-f $file){
	    closedir $dir;
	    return $file;
	}
    }
    closedir $dir;
    return "";
}

# returns next image to be processed, deletes finished images
sub getNextImage{
    my ($fname, $done);
    if (@_ > 0){
	$done = shift @_;
    }

    $fname = shift @images;
    push @processing, $fname;

    # remove from processing array
    if (defined $done && find($done, @processing)){
	my $i=0;
	foreach(@processing){
	    if (defined $_ && $_ eq $done){
		splice(@processing, $i, 1);
	    }
	    $i++;
	}

	# delete file
	 unlink($done);   # commented for testing
    }

    # if queue small enough to check for new images
    if (@images <= 10){
	#get new images
	print "read dir\n";
	readDir();
    }

    return $fname;
}

# prints the given array
sub displayArray{
    foreach (@_){
	print $_ . "\n";
    }
}

# find scalar in array
sub find($@){
    my $target = shift @_;
    foreach (@_){
        if (defined $target && defined $_ && $target eq $_){
            return 1;
        }
    }
    return 0;
}
