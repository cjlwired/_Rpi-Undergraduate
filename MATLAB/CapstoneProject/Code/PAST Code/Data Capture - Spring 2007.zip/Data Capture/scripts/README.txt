The final version of the scripts used by the Data Capture Team.

Software Used:
	Yellow Dog Linux 5
	Emacs 21.4.1
	Nano 1.3.8

Subdirectories:
	None
Files:
	README.txt
	bmp_diff
	bmp_diff_old_version
	cjpeg
	client
	client.c
	decomp.pl
	djpeg
	imgproc.pl
	imgproc.pl.save
	index.html
	listen.pl
	Makefile
	quit.pl
	rc.local
	startup.pl
