#!/usr/bin/perl
use warnings;
use strict;
use File::Copy;		#to move file
use Proc::Killfam;	#to kill children

# check for ramdisk
# test/create ramdisk directories and copy files 
# start programs

if (!(-e "/mnt/rd")) { #ramdisk does not exist?
	print "Error, ramdisk could not be found at '/mnt/rd'.\n";
	return(1);
}

#chmod ramdisk to world writeable
chmod oct('0777'), '/mnt/rd' or warn "Could not chmod 777 /mnt/rd!\n";

# these directories will be created in the ramdisk file.
my @dir=("capture","bitmap", "base");

#check/create directories using above array
foreach my $key (@dir) {
	if (-e "/mnt/rd/$key") { #if dir already exists...
		print uc($key). " exists. '/mnt/rd/$key' \n";
	} else {
		if (mkdir("/mnt/rd/$key")) {
			print uc($key)." directory '/mnt/rd/$key' created.\n";
		} else {
			print "Error creating directory '/mnt/rd/$key'. $!";
			return(1);
		}
	}
	#set chmod for dir
	chmod oct('0777'), "/mnt/rd/$key"  or warn "Could not chmod 777 /mnt/rd/$key!\n";
}
#create link to /mnt/images/processed
	if (-e "/mnt/rd/processed") {
		print "/mnt/rd/processed exists\n";
	} else {
		if (system("ln","-s", "/mnt/images/processed/", "/mnt/rd/processed")!=0) {
			warn "Error creating link for processed DIR.\n";
		}
	}

#copy base files to ramdisk's base directory

	#unlink all files in current ramdisk base
	print "Removing Files in '/mnt/rd/base/*'\n";
	chdir("/mnt/rd/base/") || die ("Could not change working directory to '/mnt/images/base': $!\n");
	foreach my $file (<*>) { # step through each file.
	    if (unlink("$file")) { print "\t $file removed.\n"; } else { warn "\t having trouble deleting $file: $!"; }
	}
	#copy new files to ramdisk base
	print "Copying Files from '/mnt/images/base/' to '/mnt/rd/base'\n";
	chdir("/mnt/images/base/") || die ("Could not change working directory to '/mnt/images/base': $!\n");
	foreach my $file (<*>) { # step through each file
		if (copy("/mnt/images/base/$file","/mnt/rd/base/$file")) { 
			print "\t $file copied.\n"; 
			#chmod file
			chmod oct('0777'), "/mnt/rd/base/$file"  or warn "Could not chmod 777 /mnt/rd/base/$file\n";
		} else { 
			warn "\t having trouble copying file $file to '/mnt/rd/base': $!"; 
		}
	}


#END OF DIRECTORY SET UP

my $pid = fork();
#CALL SERVER PERL SCRIPT
if ($pid) { #parent
	print "Starting Server.\n";
	system('perl /mnt/scripts/listen.pl');
	killfam ('QUIT', $pid);
	exit(0);
} else {	#child
	#fork again
	sleep(5);
	my $pid2 = fork();
	if ($pid2) { #parent
		print "Starting Decompression Program.\n";
		exec('perl /mnt/scripts/decomp.pl');
	} else {
		#execute C image program...
		print "Starting Image Processor Control Program.\n";
		exec('perl /mnt/scripts/imgproc.pl');
	}
}

