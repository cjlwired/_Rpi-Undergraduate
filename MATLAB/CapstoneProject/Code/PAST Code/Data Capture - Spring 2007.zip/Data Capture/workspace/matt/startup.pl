#!/usr/bin/perl
use warnings;
use strict;
use File::Copy;

# check for ramdisk
# test/create ramdisk directories and copy files 
# start programs

if (!(-e "/mnt/rd")) { #ramdisk does not exist?
	print "Error, ramdisk could not be found at '/mnt/rd'.\n";
	return(1);
}

# these directories will be created in the ramdisk file.
my @dir=("queue","bitmap", "processed", "base");

#check/create directories using above array
foreach my $key (@dir) {
	if (-e "/mnt/rd/$key") { #if dir already exists...
		print uc($key). " exists. '/mnt/rd/$key' \n";
	} else {
		if (mkdir("/mnt/rd/$key")) {
			print uc($key)." directory '/mnt/rd/$key' created.\n";
		} else {
			print "Error creating directory '/mnt/rd/$key'. $!";
			return(1);
		}
	}
}

#copy base files to ramdisk's base directory

	#unlink all files in current ramdisk base
	print "Removing Files in '/mnt/rd/base/*'\n";
	chdir("/mnt/rd/base/") || die ("Could not change working directory to '/mnt/images/base': $!\n");
	foreach my $file (<*>) { # step through each file.
	    if (unlink("$file")) { print "\t $file removed.\n"; } else { warn "\t having trouble deleting $file: $!"; }
	}
	#copy new files to ramdisk base
	print "Copying Files from '/mnt/images/base/' to '/mnt/rd/base'\n";
	chdir("/mnt/images/base/") || die ("Could not change working directory to '/mnt/images/base': $!\n");
	foreach my $file (<*>) { # step through each file
		if (copy("/mnt/images/base/$file","/mnt/rd/base/$file")) { 
			print "\t $file copied.\n"; 
		} else { 
			warn "\t having trouble copying file $file to '/mnt/rd/base': $!"; 
		}
	}

#do not delete from BMP dir because server script will resume from there...

#move stuff from processed dir to harddrive
	chdir("/mnt/rd/processed/") || die ("Could not change working directory to '/mnt/images/base': $!\n");
	foreach my $file (<*>) { # step through each file.
	    if (move("$file", "/mnt/images/processed/$file")) { print "\t $file moved to "/mnt/images/processed/$file.\n"; } else { warn "\t having trouble moving $file to '/mnt/images/processed/$file' : $!"; }
	}

#END OF DIRECTORY SET UP

my $pid = fork();
#CALL SERVER PERL SCRIPT
if ($pid) { #parent
	exec('./listen.pl');
} else {	#child
	#fork again
	my $pid2 = fork();
	if ($pid2) { #parent
		exec('./decomp.pl');
	} else {
		#execute C image program...
	}
}

