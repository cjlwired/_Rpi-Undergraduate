use IO::Socket; 
my $sock = new IO::Socket::INET ( 
	PeerAddr => 'localhost', 
	PeerPort => '31337', 
	Proto => 'tcp', 
);
die "Could not create socket: $!\n" unless $sock; 
my $thisfile;
my $base;
#loop forever
	#ask for new file
	print $sock "done:$thisfile\n"; 
while(1) {
	#wait for response
	my $line;
	$new_sock = $sock->accept();
	while (!$line) {
		$line = <new_sock>;
	}

	#filename:filename.bmp
	#basename:baseimage.bmp
	if ($line=~m/^basename:(.*)/i) {
		$base=$1;
		print "New Base Set: $1\n";
		next;
	} elsif ($line~m/^filename:(.*)/i) {
		$bitmap	  ="/mnt/rd/bitmap/$1";
		my $output="/mnt/rd/processed/$1";

	print "calling system (\"/mnt/scripts/imgproc\", $bitmap, $base, $output)";	
	#system ($program, $bitmap, $base, $output);
	if ($? == -1) { #failed...
		warn "Error calling $program with '$bitmap', '$base', '$output' \n";
	} else {
		print "Delete BMP from bitmap/$file";
		#unlink("/mnt/rd/bitmap/$file") or warn "Error, could not unlink file: /mnt/rd/bitmap/$file";
	}
	#ask for new file
	print $sock "done:$thisfile\n"; 
}
close($sock);
