    use threads; 
    use Thread::Queue;

    my $DataQueue = Thread::Queue->new; 
    $thr = threads->new(sub { 
        while ($DataElement = $DataQueue->dequeue) { 
            print "Popped $DataElement off the queue\n";
        } 
    });

    $DataQueue->enqueue(12); 
    $DataQueue->enqueue("A", "B", "C"); 
    sleep 10; 
    $DataQueue->enqueue(undef);
    $thr->join;
