use IO::Socket; 
my $sock = new IO::Socket::INET ( 
	LocalHost => 'localhost', 
	LocalPort => '31337', 
	Proto => 'tcp', 
	Listen => 1, 
	Reuse => 1, 
); 

die "Could not create socket: $!\n" unless $sock;

my $new_sock = $sock->accept(); 
my $incoming=<$new_sock>;

while($incoming!~/quit/i) {
	print $incoming;
	$new_sock = $sock->accept(); 
	$incoming=<$new_sock>; 
	print $sock "Sup...";
} 
close($sock);
