#!/usr/bin/perl
use warnings;
use strict;
use File::Copy;
use threads;
use Thread::Queue;


#read capture DIR
#decompress files
my $this="";
my $last="";
my $DataQueue = Thread::Queue->new; 

my $th1=threads->new(\&capture);
print "rawr";
	while(1) {
print "loop forever";
		while(my $DataElement = $DataQueue->dequeue) {
			print "REMOVING FILE $DataElement\n";
			my $deco=threads->new(\&decomp2, $DataElement);
			$deco->detach;
#		sleep(3000);
		}
	}

$th1->join;

sub capture() {
	while(1) {
			foreach my $file (</mnt/rd/capture/*>) { # step through each file
				if ($file gt $last) { next; }
				$DataQueue->enqueue($file);
				print "ADDED $file\n";
			}
#		sleep(5000);	# wait between searches
	}
}

sub decomp2 {
my $file=shift;
print "doing shit to $file\n";
		   system "/mnt/djpeg -grayscale -bmp /mnt/rd/capture/$file < /mnt/rd/bitmap/$file";
			unlink("/mnt/rd/capture/$file");
}
	
