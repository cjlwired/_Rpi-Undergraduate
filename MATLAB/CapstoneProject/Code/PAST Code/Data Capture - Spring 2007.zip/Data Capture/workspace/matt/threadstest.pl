    use threads;

    $Param3 = "foo"; 
    $thr = threads->new(\&sub1, "Param 1", "Param 2", $Param3); 
    $thr1 = threads->new(\&sub1, @ParamList); 
    $thr2 = threads->new(\&sub1, qw(Param1 Param2 Param3));

    @ReturnData = $thr->join; 
    @ReturnData = $thr1->join;
    @ReturnData = $thr2->join;  
    sub sub1 { 
        my @InboundParameters = @_; 
        print "In the thread\n"; 
        print "got parameters >", join("<>", @InboundParameters), "<\n"; 
    }
