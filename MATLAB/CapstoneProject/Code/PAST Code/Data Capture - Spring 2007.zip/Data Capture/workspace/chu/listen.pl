#!/usr/bin/perl

use strict;
use warnings;
use IO::Socket; 


my $sock = new IO::Socket::INET ( 
	LocalHost => 'localhost', 
	LocalPort => '31333', 
	Proto => 'tcp', 
	Listen => 1, 
	Reuse => 1, 
); 

die "Could not create socket: $!\n" unless $sock;

my (@images, @processing);
readDir();

my $new_sock = $sock->accept(); 
my $incoming = <$new_sock>;
my $nextfile;

print $new_sock "mesage received\n";
#close($new_sock);

while(!defined $incoming || $incoming!~/quit/i) {

    if (defined $incoming){
	print $incoming;
	if ($incoming =~ /list/i){
	    displayArray(@images);
	}
	elsif ($incoming =~ /process/i){
	    displayArray(@processing);
	}
	elsif ($incoming =~ /done:(.*\.bmp)?/i){
	    $nextfile = getNextImage($1);
	    if (defined $nextfile){
		print $new_sock "message received:$nextfile\n";
	    }
	    else{
		print $new_sock "message received:\n";
	    }	    
	}
    }
    else{
	# sleep?
    }
    $incoming = <$new_sock>;
}

close($new_sock);




# reads images in directory, saves to @images
sub readDir{
    opendir my $dir, '/mnt/rd/bitmap' or die ("Cannot open /mnt/rd/bitmap $!");
    chdir '/mnt/rd/bitmap' or die ("Cannot change directory: $!");

    my $file;
    #my @temp;
    while (($file = readdir $dir)){
	chomp($file);

	if (-f $file && $file =~ /.bmp$/i && !find($file, @images) && !find($file, @processing)){
	    push @images, $file;
	}
    }

    @images = sort @images;

    closedir $dir;
}

# returns next image to be processed, moves image to whereever
sub getNextImage{
    my ($fname, $done);
    if (@_ > 0){
	$done = shift @_;
    }

    $fname = shift @images;

    push @processing, $fname;

    # remove from processing array
    if (defined $done && find($done, @processing)){
	my $i=0;
	foreach(@processing){
	    if ($_ eq $done){
		splice(@processing, $i, 1);
	    }
	    $i++;
	}

	# move to processed dir
	rename $done, "../processed/$done" if defined $done;
    }

    # if checking for new images
    if (@images <= 10){
	#get new images
	print "read dir\n";
	readDir();
    }

    return $fname;
}

# prints the given array
sub displayArray{
    foreach (@_){
	print $_ . "\n";
    }
}

# find scalar in array
sub find($@){
    my $target = shift @_;
    foreach (@_){
        if ($target eq $_){
            return 1;
        }
    }
    return 0;
}
