#!/usr/bin/perl

my @array = ("001.bmp", "002.bmp", "lkjae");
my $file = "003.bmp";

if (find($file, @array)){
    print "FOUND\n";
}
else{
    print "NOT FOUND\n";
}


sub find($@){
    my $target = shift @_;
    foreach (@_){
	print "$_\n";
	if ($target == $_){
	    return 1;
	}
    }
    return 0;
}
