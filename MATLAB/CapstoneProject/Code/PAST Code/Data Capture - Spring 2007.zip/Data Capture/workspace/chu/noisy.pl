#!/usr/bin/perl

use strict;
use warnings;
use IO::Socket; 


my $sock = new IO::Socket::INET ( 
	LocalHost => 'localhost', 
	LocalPort => '31337', 
	Proto => 'tcp', 
	Listen => 1, 
	Reuse => 1, 
); 

die "Could not create socket: $!\n" unless $sock;

my $new_sock = $sock->accept(); 
my $incoming = <$new_sock>;
my $nextfile;

print $new_sock "mesage received\n";
#close($new_sock);

while(!defined $incoming || $incoming!~/quit/i) {
    print "loop\n";
    if (defined $incoming){
	print "message: $incoming\n";
    }
    print $new_sock "message\n";
    $incoming = <$new_sock>;
}

close($new_sock);
