Workspace used during development of code, includes some back-up and older code.

Software Used:
	Yellow Dog Linux 5
	Emacs 21.4.1
	Nano 1.3.8

Subdirectories:
	None
Files:
	README.txt
	caller.pl
	client
	client.c
	listen.pl
	Makefile
	noisy.pl
	output.txt
	quit.pl
	server
	server.c
	test.pl
