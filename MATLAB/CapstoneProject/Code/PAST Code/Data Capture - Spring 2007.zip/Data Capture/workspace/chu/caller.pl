#!/usr/bin/perl
use strict;
use warnings;
use IO::Socket; 

my $sock = new IO::Socket::INET ( 
	PeerAddr => 'localhost', 
	PeerPort => '31337', 
	Proto => 'tcp', 
);
die "Could not create socket: $!\n" unless $sock; 
print $sock $ARGV[0]."\n"; 

my $msg;
$msg = <$sock>;

print $msg;

$msg = <$sock>;
print $msg;

close($sock);
